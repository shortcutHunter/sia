<?php

namespace App\Objects;

use App\Objects\BaseModel;

class TahunAjaran extends BaseModel
{
	protected $table = 'tahun_ajaran';

	public $status_enum = [
		"aktif" => "Aktif",
		"nonaktif" => "Nonaktif",
	];

}