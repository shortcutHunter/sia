<?php

namespace App\Objects;

use App\Objects\BaseModel;

class Pmb extends BaseModel
{
	protected $table = 'pmb';

	public $status_enum = [
		"aktif" => "Aktif",
		"nonaktif" => "Nonaktif",
	];

	public function orang()
	{
		return $this->belongsTo(Orang::class, 'orang_id', 'id');
	}

	public function jurusan()
	{
		return $this->hasOne(Jurusan::class, 'jurusan_id', 'id');
	}
}