<?php

namespace App\Objects;

use App\Objects\BaseModel;

class File extends BaseModel
{
	protected $table = 'file';
}