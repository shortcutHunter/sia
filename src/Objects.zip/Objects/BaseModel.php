<?php

namespace App\Objects;

use Illuminate\Database\Eloquent\Model;
use App\objects\Session;

class BaseModel extends Model
{
	public $timestamps = false;
	public $like_fields = [];
	protected $guarded = [];

	public $selection_fields = [];
	public static $relation = [];

	public $file_fields = [];

	protected $dateFormat = 'd/m/Y';

	public $session;

	public function __construct(array $attributes = array())
	{
		parent::__construct($attributes);
		$this->session = new Session();
	}

	public static function getModelByName($name)
	{
		$class_name = join("", array_map("ucfirst", explode("_", $name)));
        $class_name = "App\\Objects\\".$class_name;
        $model = new $class_name();
        return $model;
	}

	public static function relationName()
	{
		$relation_name = [];
		foreach (static::$relation as $key => $value) {
			if (!$value['is_selection']) {
				array_push($relation_name, $value['name']);
			}			
		}
		return $relation_name;
	}

	public static function create(array $attributes = [])
	{
		$relation_name = self::relationName();

		foreach ($relation_name as $key => $value) {
			if (array_key_exists($value, $attributes)) {
				$relation_value = $attributes[$value];
				$object_relation = self::getModelByName($value);

				if ($value == 'file') {
					
					foreach ($relation_value as $k => $file_data) {
						$file_data_value = [
							'name' => $k,
							'file_name' => $file_data['filename'],
							'file_type' => $file_data['filetype'],
							'file' => $file_data['base64']
						];
						$object_relation_created = $object_relation->create($file_data_value);
						$attributes[$k."_id"] = $object_relation_created->id;
					}

				}else{
					$object_relation = $object_relation->create($relation_value);
					$attributes[$value."_id"] = $object_relation->id;
				}
				
				unset($attributes[$value]);
			}
		}

	    $model = static::query()->create($attributes);
	    return $model;
	}
}