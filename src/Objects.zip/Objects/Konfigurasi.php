<?php

namespace App\Objects;

use App\Objects\BaseModel;

class Konfigurasi extends BaseModel
{
	protected $table = 'konfigurasi';

	public function paket()
	{
		return $this->hasOne(Paket::class, 'paket_id', 'id');
	}

}