<?php

namespace App\Objects;

use App\Objects\BaseModel;

class Mahasiswa extends BaseModel
{
	protected $table = 'mahasiswa';

	public $selection_fields = ['status'];
	public static $relation = [
		['name' => 'orang', 'is_selection' => false],
	];

	public $status_enum = [
		"mahasiswa" => "Mahasiswa",
		"alumni"    => "Alumni",
		"dropout"   => "Dropout",
	];

	// Relation
	public function orang()
	{
		return $this->hasOne(Orang::class, 'id', 'orang_id');
	}

	public function jurusan()
	{
		return $this->hasOne(Jurusan::class, 'jurusan_id', 'id');
	}

	public function semester()
	{
		return $this->hasOne(Semester::class, 'semester_id', 'id');
	}

	public function tahun_ajaran()
	{
		return $this->hasOne(TahunAjaran::class, 'tahun_ajaran_id', 'id');
	}


	public function pengajuan_ks()
	{
		return $this->hasMany(PengajuanKs::class, 'mahasiswa_id', 'id');
	}

	public function riwayat_belajar()
	{
		return $this->hasMany(RiwayatBelajar::class, 'mahasiswa_id', 'id');
	}

	public function mahasiswa_bimbingan()
	{
		return $this->hasMany(MahasiswaBimbingan::class, 'mahasiswa_id', 'id');
	}

	public function register_ulang()
	{
		return $this->hasMany(RegisterUlang::class, 'mahasiswa_id', 'id');
	}


}