<?php

namespace App\Objects;

use App\Objects\BaseModel;

class PengajuanKs extends BaseModel
{
	protected $table = 'pengajuan_ks';

	public $status_enum = [
		"proses" => "Proses",
		"terima" => "Terima",
		"tolak" => "Tolak",
	];

	public function semester()
	{
		return $this->hasOne(Semester::class, 'semester_id', 'id');
	}

	public function tahun_ajaran()
	{
		return $this->hasOne(TahunAjaran::class, 'tahun_ajaran_id', 'id');
	}

	public function mahasiswa()
	{
		return $this->belongsTo(Mahasiswa::class, 'mahasiswa_id', 'id');
	}


	public function pengajuan_ks_detail()
	{
		return $this->hasMany(PengajuanKsDetail::class, 'pengajuan_ks_id', 'id');
	}
}