<?php

namespace App\Objects;

use App\Objects\BaseModel;

class MataKuliahDiampuh extends BaseModel
{
	protected $table = 'mata_kuliah_diampuh';

	public $status_enum = [
		"aktif" => "Aktif",
		"nonaktif" => "Nonaktif",
	];

	public function dosen_pjmk()
	{
		return $this->belongsTo(DosenPjmk::class, 'dosen_pjmk_id', 'id');
	}

	public function mata_kuliah()
	{
		return $this->hasOne(MataKuliah::class, 'mata_kuliah_id', 'id');
	}

	public function konfigurasi_nilai()
	{
		return $this->hasOne(KonfigurasiNilai::class, 'mata_kuliah_diampuh_id', 'id');
	}
	
}