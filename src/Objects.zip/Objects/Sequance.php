<?php

namespace App\Objects;

use App\Objects\BaseModel;

class Sequance extends BaseModel
{
	protected $table = 'sequance';

}