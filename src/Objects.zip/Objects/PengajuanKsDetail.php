<?php

namespace App\Objects;

use App\Objects\BaseModel;

class PengajuanKsDetail extends BaseModel
{
	protected $table = 'pengajuan_ks_detail';

	public $status_enum = [
		"terima" => "Terima",
		"tolak" => "Tolak",
	];

	public function mata_kuliah()
	{
		return $this->hasOne(MataKuliah::class, 'mata_kuliah_id', 'id');
	}

	public function pengajuan_ks()
	{
		return $this->belongsTo(PengajuanKs::class, 'pengajuan_ks_id', 'id');
	}

}