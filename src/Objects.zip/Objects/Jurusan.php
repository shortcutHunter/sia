<?php

namespace App\Objects;

use App\Objects\BaseModel;

class Jurusan extends BaseModel
{
	protected $table = 'jurusan';
}