<?php

namespace App\Objects;

use App\Objects\BaseModel;

class Karyawan extends BaseModel
{
	protected $table = 'karyawan';

	public $jenis_karyawan_enum = [
		"dosen" => "Dosen",
		"pegawai" => "Pegawai",
	];

	public $status_enum = [
		"aktif" => 'Aktif',
		"nonaktif" => 'Nonaktif',
	];

	public function orang()
	{
		return $this->hasOne(Orang::class, 'id', 'orang_id');
	}

	public function dosen_pa()
	{
		return $this->hasOne(DosenPa::class, 'karyawan_id', 'id');
	}
	public function dosen_pjmk()
	{
		return $this->hasOne(DosenPjmk::class, 'karyawan_id', 'id');
	}
}