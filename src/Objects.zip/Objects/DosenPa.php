<?php

namespace App\Objects;

use App\Objects\BaseModel;

class DosenPa extends BaseModel
{
	protected $table = 'dosen_pa';

	public $status_enum = [
		"aktif" => "Aktif",
		"nonaktif" => "Nonaktif",
	];

	public function karyawan()
	{
		return $this->belongsTo(Karyawan::class, 'karyawan_id', 'id');
	}

	public function tahun_ajaran()
	{
		return $this->hasOne(TahunAjaran::class, 'tahun_ajaran_id', 'id');
	}

	public function semester()
	{
		return $this->hasOne(Semester::class, 'semester_id', 'id');
	}


	public function mahasiswa_bimbingan()
	{
		return $this->hasMany(MahasiswaBimbingan::class, 'dosen_pa_id', 'id');
	}
}