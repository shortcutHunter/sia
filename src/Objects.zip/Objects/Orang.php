<?php

namespace App\Objects;

use App\Objects\BaseModel;

class Orang extends BaseModel
{
	protected $table = 'orang';

	public $selection_fields = ['status', 'jenis_kelamin'];
	public static $relation = [
		['name' => 'agama', 'is_selection' => true]
	];

	public $status_enum = [
		"aktif" => "Aktif",
		"inaktif" => "Inaktif",
		"berhenti" => "Berhenti",
	];

	public $jenis_kelamin_enum = [
		"l" => "Laki-laki",
		"p" => "Perempuan"
	];

	public $file_fields = ['ijazah', 'ktp', 'surket_menikah'];

	public function agama()
	{
		return $this->hasOne(Agama::class, 'id', 'agama_id');
	}

	public function mahasiswa()
	{
		return $this->belongsTo(Mahasiswa::class, 'id', 'orang_id');
	}
	public function karyawan()
	{
		return $this->belongsTo(Karyawan::class, 'id', 'orang_id');
	}
	public function user()
	{
		return $this->belongsTo(User::class, 'id', 'orang_id');
	}

	public function kwitansi()
	{
		return $this->hasMany(Kwitansi::class, 'id', 'orang_id');
	}

	public function pmb()
	{
		return $this->hasOne(Pmb::class, 'orang_id', 'id');
	}

	// File
	public function ijazah()
	{
		return $this->hasOne(File::class, 'id', 'ijazah_id');
	}
	public function ktp()
	{
		return $this->hasOne(File::class, 'id', 'ktp_id');
	}
	public function surket_menikah()
	{
		return $this->hasOne(File::class, 'id', 'surket_menikah_id');
	}
}